from pydantic import BaseModel

class fetchTemplate(BaseModel):
    url: str